interface AssocStringString {
    [key: string]: string;
}

interface StudentData {
    name: string;
    firstname: string;
    matrikel: number;
}

interface HighScoreData {
    name: string;
    highscore: number;
}