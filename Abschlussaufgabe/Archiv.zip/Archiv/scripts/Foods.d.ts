declare namespace seaworld_inheritance {
    class Foods extends Bubbles {
        constructor(_x: number, _y: number, _c1: string);
        update(): void;
        move(): void;
    }
}
